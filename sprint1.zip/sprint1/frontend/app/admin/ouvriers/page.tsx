'use client';
import { useEffect, useState } from 'react';
import { ouvriersApi, habTypesApi } from '@/lib/api';

const fmt = (d: string) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

function Badge({ statut }: { statut: string }) {
  const ok = ['VALIDE','ACTIF'].includes(statut);
  const warn = statut === 'SUSPENDU';
  return <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${ok?'bg-green-100 text-green-800':warn?'bg-yellow-100 text-yellow-800':'bg-red-100 text-red-800'}`}>{statut}</span>;
}

const GROUPES_SANGUINS = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];

export default function CollaborateursPage() {
  const [collaborateurs, setCollaborateurs] = useState<any[]>([]);
  const [types, setTypes] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    nom: '', prenom: '', telephone: '', email: '', role: '', entreprise: '',
    dateEmbauche: '', adresse: '', nationalite: '', groupeSanguin: '',
    numeroPieceIdentite: '', typePieceIdentite: 'CIN',
    contactUrgenceNom: '', contactUrgenceTel: '',
  });
  const [habForm, setHabForm] = useState({ typeId: '', dateObtention: '', dateExpiration: '', entreprise: '' });

  const load = () => {
    Promise.all([ouvriersApi.getAll({ search, limit: 100 }), habTypesApi.getAll()])
      .then(([o, t]) => { setCollaborateurs(o.data.data ?? o.data); setTypes(t.data); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [search]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await ouvriersApi.create(form);
    setShowForm(false);
    setForm({ nom:'',prenom:'',telephone:'',email:'',role:'',entreprise:'',dateEmbauche:'',adresse:'',nationalite:'',groupeSanguin:'',numeroPieceIdentite:'',typePieceIdentite:'CIN',contactUrgenceNom:'',contactUrgenceTel:'' });
    load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce collaborateur ?')) return;
    await ouvriersApi.delete(id); setSelected(null); load();
  };

  const handleAddHab = async (e: React.FormEvent) => {
    e.preventDefault();
    await ouvriersApi.addHabilitation(selected.id, habForm);
    setHabForm({ typeId:'',dateObtention:'',dateExpiration:'',entreprise:'' });
    const updated = await ouvriersApi.getOne(selected.id);
    setSelected(updated.data); load();
  };

  const handleDeleteHab = async (habId: string) => {
    await ouvriersApi.deleteHabilitation(habId);
    const updated = await ouvriersApi.getOne(selected.id);
    setSelected(updated.data); load();
  };

  const qrValue = (id: string) => `${typeof window !== 'undefined' ? window.location.origin : ''}/verify/collaborateur-${id}`;

  const Field = ({ label, value, onChange, type = 'text', required = false, children }: any) => (
    <div>
      <label className="text-xs text-slate-500 mb-1 block">{label}{required && ' *'}</label>
      {children ?? <input type={type} required={required} value={value} onChange={e => onChange(e.target.value)}
        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-slate-400" />}
    </div>
  );

  return (
    <div className="p-4 md:p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-semibold text-slate-800">👷 Collaborateurs</h1>
        <button onClick={() => setShowForm(true)} className="text-sm bg-[#D50032] text-white px-4 py-2 rounded-xl">+ Ajouter</button>
      </div>

      <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un collaborateur..."
        className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm mb-4 focus:outline-none focus:border-slate-400" />

      {showForm && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 mb-5">
          <h3 className="font-semibold text-slate-800 mb-4">Nouveau collaborateur</h3>
          <form onSubmit={handleCreate} className="space-y-4">
            <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Informations principales</p>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Nom" value={form.nom} onChange={(v: string) => setForm({...form,nom:v})} required />
              <Field label="Prénom" value={form.prenom} onChange={(v: string) => setForm({...form,prenom:v})} required />
              <Field label="Téléphone" value={form.telephone} onChange={(v: string) => setForm({...form,telephone:v})} required />
              <Field label="Email" value={form.email} type="email" onChange={(v: string) => setForm({...form,email:v})} />
              <Field label="Rôle / Poste" value={form.role} onChange={(v: string) => setForm({...form,role:v})} required />
              <Field label="Entreprise" value={form.entreprise} onChange={(v: string) => setForm({...form,entreprise:v})} />
              <Field label="Date embauche" value={form.dateEmbauche} type="date" onChange={(v: string) => setForm({...form,dateEmbauche:v})} />
              <Field label="Adresse" value={form.adresse} onChange={(v: string) => setForm({...form,adresse:v})} />
            </div>

            <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mt-2">Informations complémentaires</p>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Nationalité" value={form.nationalite} onChange={(v: string) => setForm({...form,nationalite:v})} />
              <Field label="Groupe sanguin">
                <select value={form.groupeSanguin} onChange={e => setForm({...form,groupeSanguin:e.target.value})}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none bg-white">
                  <option value="">Sélectionner...</option>
                  {GROUPES_SANGUINS.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </Field>
              <Field label="Type pièce d'identité">
                <select value={form.typePieceIdentite} onChange={e => setForm({...form,typePieceIdentite:e.target.value})}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none bg-white">
                  <option value="CIN">CIN</option>
                  <option value="PASSEPORT">Passeport</option>
                </select>
              </Field>
              <Field label="Numéro pièce d'identité" value={form.numeroPieceIdentite} onChange={(v: string) => setForm({...form,numeroPieceIdentite:v})} />
            </div>

            <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mt-2">Contact urgence</p>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Nom contact urgence" value={form.contactUrgenceNom} onChange={(v: string) => setForm({...form,contactUrgenceNom:v})} />
              <Field label="Tél. contact urgence" value={form.contactUrgenceTel} onChange={(v: string) => setForm({...form,contactUrgenceTel:v})} />
            </div>

            <div className="flex gap-2 mt-2">
              <button type="submit" className="bg-[#D50032] text-white px-4 py-2 rounded-xl text-sm">Créer</button>
              <button type="button" onClick={() => setShowForm(false)} className="border border-slate-200 px-4 py-2 rounded-xl text-sm text-slate-600">Annuler</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {/* Liste */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          {loading ? <div className="p-8 text-center text-slate-400">Chargement...</div>
            : collaborateurs.map(c => {
              const hasExpire = c.habilitations?.some((h: any) => h.statut === 'EXPIRE');
              return (
                <div key={c.id} onClick={() => setSelected(c)}
                  className={`flex items-center gap-3 px-4 py-3 border-b border-slate-100 cursor-pointer hover:bg-slate-50 ${selected?.id===c.id?'bg-blue-50':''}`}>
                  <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center text-xs font-semibold text-blue-800">
                    {c.prenom?.[0]}{c.nom?.[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-slate-800">{c.prenom} {c.nom}</p>
                    <p className="text-xs text-slate-400 truncate">{c.role || '—'} {c.entreprise ? `· ${c.entreprise}` : ''}</p>
                  </div>
                  <span className={`w-2 h-2 rounded-full flex-shrink-0 ${hasExpire?'bg-red-500':'bg-green-500'}`} />
                </div>
              );
            })}
        </div>

        {/* Détail */}
        {selected && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 overflow-y-auto max-h-[80vh]">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-slate-800 text-lg">{selected.prenom} {selected.nom}</h3>
                <p className="text-slate-500 text-sm">{selected.role || '—'} {selected.entreprise ? `· ${selected.entreprise}` : ''}</p>
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <a href={`data:text/plain,${encodeURIComponent(qrValue(selected.id))}`}
                  download={`qr-${selected.nom}.txt`}
                  className="text-xs border border-slate-200 px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-50">
                  📋 Lien QR
                </a>
                <button onClick={() => handleDelete(selected.id)}
                  className="text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg hover:bg-red-50">
                  Supprimer
                </button>
              </div>
            </div>

            {/* Infos */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                ['📱 Téléphone', selected.telephone],
                ['📧 Email', selected.email || '—'],
                ['🏢 Entreprise', selected.entreprise || '—'],
                ['📅 Embauche', fmt(selected.dateEmbauche)],
                ['🌍 Nationalité', selected.nationalite || '—'],
                ['🩸 Groupe sanguin', selected.groupeSanguin || '—'],
                ['🪪 Pièce identité', selected.numeroPieceIdentite ? `${selected.typePieceIdentite}: ${selected.numeroPieceIdentite}` : '—'],
                ['📍 Adresse', selected.adresse || '—'],
                ['🚨 Contact urgence', selected.contactUrgenceNom ? `${selected.contactUrgenceNom} — ${selected.contactUrgenceTel || ''}` : '—'],
              ].map(([label, value]) => (
                <div key={label} className="bg-slate-50 px-3 py-2 rounded-lg">
                  <p className="text-slate-400 text-xs">{label}</p>
                  <p className="text-slate-700 font-medium text-xs mt-0.5 truncate">{value}</p>
                </div>
              ))}
            </div>

            {/* Habilitations */}
            <div>
              <h4 className="text-sm font-semibold text-slate-700 mb-2">Habilitations</h4>
              <div className="space-y-2">
                {selected.habilitations?.map((h: any) => (
                  <div key={h.id} className={`flex items-center justify-between p-3 rounded-xl border ${h.statut==='VALIDE'?'bg-green-50 border-green-200':'bg-red-50 border-red-200'}`}>
                    <div>
                      <p className="text-sm font-medium">{h.nom}</p>
                      <p className="text-xs text-slate-500">Expire le {fmt(h.dateExpiration)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold ${h.statut==='VALIDE'?'text-green-700':'text-red-700'}`}>{h.statut}</span>
                      <button onClick={() => handleDeleteHab(h.id)} className="text-slate-300 hover:text-red-500 text-lg leading-none">×</button>
                    </div>
                  </div>
                ))}
                {(!selected.habilitations || selected.habilitations.length === 0) && <p className="text-slate-400 text-sm italic">Aucune habilitation</p>}
              </div>

              <form onSubmit={handleAddHab} className="mt-3 p-3 bg-slate-50 rounded-xl space-y-2">
                <p className="text-xs font-semibold text-slate-600">Ajouter une habilitation</p>
                <select required value={habForm.typeId} onChange={e => setHabForm({...habForm,typeId:e.target.value})}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none bg-white">
                  <option value="">Type d'habilitation...</option>
                  {types.map((t: any) => <option key={t.id} value={t.id}>{t.nom}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <input type="date" required value={habForm.dateObtention} onChange={e => setHabForm({...habForm,dateObtention:e.target.value})}
                    className="border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none" placeholder="Date obtention" />
                  <input type="date" required value={habForm.dateExpiration} onChange={e => setHabForm({...habForm,dateExpiration:e.target.value})}
                    className="border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none" placeholder="Date expiration" />
                </div>
                <button type="submit" className="w-full bg-slate-800 text-white py-2 rounded-lg text-sm hover:bg-slate-700">Ajouter</button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
